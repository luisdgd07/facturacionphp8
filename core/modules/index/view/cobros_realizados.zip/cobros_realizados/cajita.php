<?php
$sucursales = SuccursalData::VerId($_GET["id_sucursal"]);
?>
  <div class="content-wrapper">
          <section class="content-header">
            <h1><i class='glyphicon glyphicon-shopping-cart' style="color: orange;"></i>
      Lista de Cobros realizados 
    </h1>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
         <div class="box-body">
          <div class="table-responsive">
            <?php
            $users = CobroCabecera::totalcobros2($sucursales->id_sucursal);
			
			 var_dump($users);
            //if(count($users)>0){
				
				 
              ?>
              <table id="example1" class="table table-bordered table-dark" style="width:100%">
                <thead>
                   <th></th>				
                  <th>Nro.</th>
                  <th width="120px">Recibo</th>
                  <th>total cobro</th>
      
                  <th>Fecha de Cobro</th>
                  <th>Cambio</th>
                  <td>Tipo Moneda</td>
				  <td>Estado</td>
                
                </thead>
                <tbody>
                  <?php
                  foreach($users as $sell){
                    ?>
                    <tr>
                       <?php
                     // $operations = CobroDetalleData::totalcobrosdet($sell->COBRO_ID );
                       //count($operations);
                       
                      ?> 
					  
					  <td style="width:30px;">
                              <a href="index.php?view=detalleventaproductoremision&id_venta=<?php echo $sell->id_venta; ?>" class="btn btn-xs btn-default"><i class="glyphicon glyphicon-eye-open" style="color: orange;"></i></a>
                            </td>
                      <td><?php echo $sell->COBRO_ID; ?></td>
                      <td class="width:30px;">
                      
                      <?php echo $sell->TOTAL_COBRO; ?>
					  
                      </td>
                      <td><?php
              
                      ?></td>
           
                      <td><?php echo $sell->FECHA_COBRO; ?></td>
                      
					  
					  <td><?php if ($sell->tipomoneda_id=="") {
                        echo "--";
                      } else {
                        if ($sell->VerTipoModena()->simbolo=="US$") {echo  $sell->cambio2; }else {echo  1 ;}
                      } ?></td>
                      <td style="width:200px;">
                        <?php if ($sell->tipomoneda_id=="") {
                          echo "--";
                        } else {
                          echo $sell->VerTipoModena()->nombre;
                        } ?>
                      </td>
					  
					  
					   <td><?php if ($sell->estado==1) {
                        echo "pendiente";
                      } else {
                        if ($sell->estado==0) {echo  "facturado"; }
                      } ?></td>
					  
					 
                    </tr>
                    <?php
                  }
               // }else{
                 // echo "<p class='alert alert-danger'>No hay cobro realizado</p>";
                //}
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>   
</div>