<!-- Content Wrapper. Contains page content -->

<body id="cuerpoPagina">
  <div class="zona_impresion">
    <?php
    $total = 0;
    $moneda = 'PYG';
    $ventas = VentaData::getById($_GET["id_venta"]);
    $procesos = OperationData::getAllProductsBySellIddd($_GET["id_venta"]);
    if ($ventas->VerTipoModena()->simbolo == "₲") {
      $moneda = 'PYG';
    } else {
      $moneda = 'USD';
    }
    ?>
    <?= $rucEmisor = $ventas->verSocursal()->ruc ?>
    <?= $telefonoEmisor =  $ventas->verSocursal()->telefono ?>
    <?= $ventas->VerConfiFactura()->timbrado1 ?>

    <?php if ($ventas->numerocorraltivo >= 1 & $ventas->numerocorraltivo < 10) : ?>
      <?= $facturaN =    "000000" . $ventas->numerocorraltivo ?>
    <?php else : ?>
      <?php if ($ventas->numerocorraltivo >= 10 & $ventas->numerocorraltivo < 100) : ?>
        <?= $facturaN = "00000" . $ventas->numerocorraltivo ?>
      <?php else : ?>
        <?php if ($ventas->numerocorraltivo >= 100 & $ventas->numerocorraltivo < 1000) : ?>
          <?= $facturaN =  "0000" . $ventas->numerocorraltivo ?>
        <?php else : ?>
          <?php if ($ventas->numerocorraltivo >= 1000 & $ventas->numerocorraltivo < 10000) : ?>
            <?= $facturaN = "000" . $ventas->numerocorraltivo ?>
          <?php else : ?>
            <?php if ($ventas->numerocorraltivo >= 100000 & $ventas->numerocorraltivo < 1000000) : ?>
              <?= $facturaN = "00" . $ventas->numerocorraltivo ?>
            <?php else : ?>
              <?php if ($ventas->numerocorraltivo >= 1000000 & $ventas->numerocorraltivo < 10000000) : ?>
                <?= $facturaN = "0" . $ventas->numerocorraltivo ?>
              <?php else : ?>
                SIN ACCION
              <?php endif ?>
            <?php endif ?>
          <?php endif ?>
        <?php endif ?>
      <?php endif ?>
    <?php endif ?>
    <?php if ($ventas->getCliente()->tipo_doc == "SIN NOMBRE") {
      $ventas->getCliente()->tipo_doc;
      $cliente = $ventas->getCliente()->tipo_doc;
    } else {
      $ventas->getCliente()->nombre . " " . $ventas->getCliente()->apellido;
      $cliente = $ventas->getCliente()->nombre . " " . $ventas->getCliente()->apellido;
    } ?>

    <?= $rucCliente = $ventas->getCliente()->dni ?>


    <?= $direccionCliente = $ventas->getCliente()->direccion ?>


    <?= $vendedor = $ventas->getUser()->nombre . " " . $ventas->getUser()->apellido ?>

  </div>

</body>


<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">

    <form class="form-horizontal" role="form" method="post" hidden name="facturacion" action="index.php?action=agregarenvio" enctype="multipart/form-data">
      <input type="text" name="venta" id="venta" value="<?php echo $_GET['id_venta'] ?>">
      <input type="text" name="estado" id="estado" value="">
      <input type="text" name="xml" id="xml" value="">
      <button type="submit">envio</button>
    </form>
    <h1><i class='fa fa-shopping-cart' style="color: orange;"></i>
      DETALLE FACTURA VENTA
      <!-- <marquee> Lista de Medicamentos</marquee> -->
    </h1>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-body">
            <input type="hidden" name="xml_string" id="xml_string">
            <input type="hidden" name="certandkey" id="certandkey">
            <?php if (isset($_GET["id_venta"]) && $_GET["id_venta"] != "") : ?>
              <?php

              $sell = VentaData::getById($_GET["id_venta"]);
              $operations = OperationData::getAllProductsBySellIddd($_GET["id_venta"]);
              $total = 0;
              ?>
              <?php
              if (isset($_COOKIE["selled"])) {
                foreach ($operations as $operation) {
                  //    print_r($operation);
                  $qx = OperationData::getQYesFf($operation->producto_id);
                  // print "qx=$qx";
                  $p = $operation->getProducto();
                  if ($qx == 0) {
                    echo "<p class='alert alert-danger'>El producto <b style='text-transform:uppercase;'> $p->nombre</b> tiene existencia 0 realice compras para abastecer su stock.</p>";
                  } else if ($qx <= $p->inventario_minimo / 2) {
                    echo "<p class='alert alert-danger'>Atención el producto <b style='text-transform:uppercase;'> $p->nombre</b> ya tiene menos a su stock Minimo de abastecerlo</p>";
                  } else if ($qx <= $p->inventario_minimo) {
                    echo "<p class='alert alert-warning'>El producto <b style='text-transform:uppercase;'> $p->nombre</b>ha llegado a su stock Minimo debe abastecerlo.</p>";
                  }
                }
                setcookie("selled", "", time() - 18600);
              }

              ?>
              <?php if ($sell->numerocorraltivo == "") : ?>
              <?php else : ?>
                <table class="table table-bordered">
                  <tr>
                    <th style="color: blue;">Factura:</th>
                    <th><?php if ($sell->numerocorraltivo >= 1 & $sell->numerocorraltivo < 10) : ?>
                        <?php echo "000000" . $sell->numerocorraltivo; ?>
                      <?php else : ?>
                        <?php if ($sell->numerocorraltivo >= 10 & $sell->numerocorraltivo < 100) : ?>
                          <?php echo "00000" . $sell->numerocorraltivo; ?>
                        <?php else : ?>
                          <?php if ($sell->numerocorraltivo >= 100 & $sell->numerocorraltivo < 1000) : ?>
                            <?php echo "0000" . $sell->numerocorraltivo; ?>
                          <?php else : ?>
                            <?php if ($sell->numerocorraltivo >= 1000 & $sell->numerocorraltivo < 10000) : ?>
                              <?php echo "000" . $sell->numerocorraltivo; ?>
                            <?php else : ?>
                              <?php if ($sell->numerocorraltivo >= 10000 & $sell->numerocorraltivo < 100000) : ?>
                                <?php echo "00" . $sell->numerocorraltivo; ?>
                              <?php else : ?>
                              <?php endif ?>
                            <?php endif ?>
                          <?php endif ?>
                        <?php endif ?>
                      <?php endif ?></th>
                    <th style="color: blue;">Inicio Timbrado:</th>

                    <th><?php echo  date('d-m-Y', strtotime($sell->VerConfiFactura()->inicio_timbrado)); ?></th>

                    <th style="color: blue;">Fin. Timbrado:</th>
                    <th><?php echo  date('d-m-Y', strtotime($sell->VerConfiFactura()->fin_timbrado)); ?></th>



                    <th style="color: blue;">Tipo de Comprobante:</th>
                    <th><?php echo $sell->VerConfiFactura()->comprobante1; ?></th>
                  </tr>
                </table>
              <?php endif ?>
              <br>
              <table class="table table-bordered">
                <?php if ($sell->cliente_id != "") :
                  $client = $sell->getCliente();
                ?>
                  <tr>
                    <td style="width:150px; text-transform:uppercase;" class="alert alert-warning"><b>Cliente</b></td>




                    <?php
                    $dptClient = $client->departamento_id;
                    $distClient = $client->distrito_id;
                    if ($client->tipo_doc == "SIN NOMBRE") {
                      echo  $client->tipo_doc;
                    } else {
                      echo  $client->nombre . " " . $client->apellido;
                    } ?>

                    <?php


                    ?>



                  </tr>

                <?php endif; ?>
                <?php if ($sell->usuario_id != "") :
                  $user = $sell->getUser();
                ?>
                  <tr>
                    <td class="alert alert-warning"><b>Atendido por</b></td>
                    <td class="alert alert-warning"><?php echo $user->nombre . " " . $user->apellido; ?></td>
                  </tr>
                <?php endif; ?>
              </table>
              <br>
              <table class="table table-bordered table-hover">
                <thead>
                  <th>Codigo</th>
                  <th>Cantidad</th>
                  <th>Nombre del Producto</th>
                  <th>Precio Unitario</th>
                  <th>Total</th>

                </thead>
                <?php
                $precio = 0;
                $total3 = 0;
                $total4 = 0;
                $productosItem  = array();

                foreach ($operations as $operation) {
                  $product  = $operation->getProducto();
                  array_push($productosItem, json_encode(array(
                    "codigo" => $product->codigo,
                    "descripcion" => $product->nombre,
                    "observacion" => "",
                    "unidadMedida" => 77,
                    "cantidad" => $operation->q,
                    "precioUnitario" => $operation->precio,
                    "cambio" => "0",
                    "ivaTipo" => 1,
                    "ivaBase" => "100",
                    "iva" => "10",
                    "lote" => "",
                    "vencimiento" => "",
                    "numeroSerie" => "",
                    "numeroPedido" => ""
                  )));

                  // array_push($productosItem, json_encode(array("codigo" => $product->codigo, "cantidad" => $operation->q, "descripcion" => $product->nombre, "observacion" => "", "precioUnitario" => $operation->precio, "iva" =>  $product->impuesto)));
                  // array_push($productosItem, [array("codigo" => 'aaa')]);
                  // var_dump(array("Oso" => true, "Gato" => null));
                ?>
                  <tr>
                    <td><?php echo $product->codigo; ?></td>
                    <td><?php echo $operation->q; ?></td>
                    <td><?php echo $product->nombre; ?></td>





                    <td><?php echo number_format(($operation->precio * $operation->q), 2, ",", "."); ?></td>



                    <td><?php echo number_format(($operation->precio * $operation->q), 2, ",", "."); ?></td>
                    </b></td>
                  </tr>
                <?php
                }
                ?>
              </table>
              <br><br>
              <div class="row">
                <div class="col-md-4">
                  <table class="table table-bordered">

                    <tr>
                      <td>
                        <h4>Subtotal: </h4>
                      </td>
                      <td>
                        <h4><?php echo number_format($sell->total, 2, ",", "."); ?></h4>
                      </td>

                      </td>
                    </tr>
                    <tr>
                      <td>
                        <h4><b>Total:</b></h4>
                      </td>

                      <?php

                      ?>

                      <td>
                        <h4><b><?php $total = $sell->total; ?></b></h4>
                      </td>
                    </tr>
                  </table>
                </div>
              </div>
              <div class="box">
                <div class="box-body">
                  <div class="box box-danger">
                  </div>
                  <div class="row">
                    <div class="col-sm">
                      <a target="_BLANK" href="impresionticket.php?id_venta=<?php echo $_GET["id_venta"] ?>" class="btn btn-primary btn-sm btn-flat"><i class='fa fa-file-code-o' style="color: orange"></i> Imprimir</a>
                    </div>
                    <br>
                    <?php if ($sell->enviado === 'Aprobado') {
                      echo '<span style="padding:10px" class=" bg bg-success">Aprobado por la SET</span>';
                    } else { ?>
                      <div class="col-sm">
                        <button onclick="enviar()" class="btn btn-primary btn-sm btn-flat" id="boton_firma" name="boton_firma"><i class='fa fa-file-code-o' style="color: orange"></i> Enviar factura</button>
                      </div>
                    <?php } ?>
                    <div>

                    </div>
                    <!-- <div class="col-sm">
                      <a target="_BLANK" class="btn btn-primary btn-sm btn-flat" id="boton_prueba" name="boton_prueba"><i class='fa fa-file-code-o' style="color: orange"></i> Generar XML</a>
                    </div> -->



                  </div>
                </div>

              </div>
            <?php else : ?>
              501 Internal Error
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  function enviar() {
    console.log("envio");
    Swal.fire({
      title: 'Enviando',
      icon: 'info',
    })
    var cambio = '<?php echo $ventas->cambio2 ?>'
    console.log(cambio);
    var tipo = '<?php echo $sell->metodopago ?>';
    if (tipo == 'CONTADO')
      var telEmisor = '<?php echo $telefonoEmisor ?>';
    // var factura = '<?php echo $facturaN ?>';
    var rucEmisor = '<?php echo $rucEmisor ?>';
    var cliente = '<?php echo $cliente ?>';
    var dirCliente = '<?php echo $direccionCliente ?>';
    var telCliente = '<?php echo $ventas->getCliente()->telefono ?>';
    var rucCliente = '<?= $ventas->getCliente()->dni ?>';
    var fechaVenta = '<?php echo date("Y-m-d-h-i", strtotime($ventas->fecha)) ?>'
    var items = JSON.stringify(<?php echo json_encode($productosItem) ?>);
    var departamentoCliente = '<?= $dptClient ?>';
    var distritoCliente = '<?= $distClient ?>';
    console.log(items);
    var total = '<?= $total ?>';
    var moneda = '<?= $moneda ?>';
    $.ajax({
      url: "http://35.172.70.62:3000/enviar",
      // url: "http://35.172.70.62:3000/consultaruc",
      // url: "http://localhost:3000/enviar",
      type: "POST",
      data: {
        telEmisor: telEmisor,
        rucEmisor: rucEmisor,
        cliente: cliente,
        dirCliente: dirCliente,
        telCliente: telCliente,
        factura: 1319855,
        total: total,
        moneda: moneda,
        fechaVenta: fechaVenta,
        items: items,
        tipo: tipo,
        cambio: cambio,
        departamentoCliente: departamentoCliente,
        distritoCliente: distritoCliente
      },
      success: function(dataResult) {
        console.log('enviando')
        // try {
        let data = dataResult;
        console.log(data['file']);
        document.getElementById('xml').value = data['file'];
        document.getElementById('estado').value = data['response']['ns2:rRetEnviDe']['ns2:rProtDe']['ns2:dEstRes'];

        Swal.fire({
          title: data['response']['ns2:rRetEnviDe']['ns2:rProtDe']['ns2:dEstRes'],
          text: 'Respuesta: ' + data['response']['ns2:rRetEnviDe']['ns2:rProtDe']['ns2:gResProc']['ns2:dMsgRes'],
          icon: 'info',
          confirmButtonText: 'Aceptar'
        });
        setTimeout(function() {
          document.facturacion.submit();

        }, 5000);
        // } catch (e) {
        //   Swal.fire({
        //     title: "Error",
        //     icon: 'danger',
        //     confirmButtonText: 'Aceptar'
        //   });
        // }

      },

    });

    // $.ajax({
    //   // url: "http://35.172.70.62:3000/enviar",
    //   url: "http://localhost:3000/consultaruc",
    //   type: "POST",
    //   data: {
    //     ruc: rucEmisor,
    //   },
    //   success: function(dataResult) {
    //     console.log('enviando')
    //     console.log(dataResult)

    //   },

    // });




  }
</script>